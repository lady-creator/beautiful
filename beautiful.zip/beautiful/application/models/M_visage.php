	<?php defined('BASEPATH') OR exit('No direct script access allowed');
  class M_visage extends CI_Model {

		public function addvisage($options)
		{
				$this->db->insert('visage', $options);
			//Si le champs est ue cle auto increment
			//return $this->db->insert_id();
			// si non auto increment
			return $this->db->affected_rows();

  }

  public function geta($limit,$start)
  {    
    $this->db->select('*');
    $this->db->from('visage');
    $this->db->limit($limit, $start);
    $query = $this->db->get()->result();   
    return $query;
  }
  

  public function getvisage($options=NULL){
 
 if(isset($options['ep'])) $this->db->where('ep', $options['ep']);
  if(isset($options['idv'])) $this->db->where('idv', $options['idv']);
  if(isset($options['bril'])) $this->db->where('bril', $options['bril']);
  if(isset($options['Pidpers'])) $this->db->where('Pidpers', $options['Pidpers']);
  if(isset($options['tp'])) $this->db->where('tp', $options['tp']);
  if(isset($options['n_tel'])) $this->db->where('n_tel', $options['n_tel']);
  if(isset($options['statut'])) $this->db->where('statut', $options['statut']);
 
  if(isset($options['ville'])) $this->db->where('ville', $options['ville']);
  $query = $this->db->get('visage');
      return $query->result();
}
public function updatevisage($options)
    { 
      if(isset($options['idv'])) $this->db->set('idv', $options['idv']);
      if(isset($options['login'])) $this->db->set('login', $options['login']);
      if(isset($options['date_naiss'])) $this->db->set('date_naiss', $options['date_naiss']);
     
      if(isset($options['statut'])) $this->db->set('statut', $options['statut']);
     
      if(isset($options['ville'])) $this->db->set('ville', $options['ville']);
      $this->db->where('idv', $options['idv']);
     $this->db->update('visage', $options);
      return $this->db->insert_id();
    }

    public function delvisage($id ){
      if(isset($options['nom'])) $this->db->where('nom', $options['nom']);
      if(isset($options['tel'])) $this->db->where('tel', $options['tel']);
        
      if(isset($options['datesave']))$this->db->where('datesave',$options['datesave']);
          

      $this->db->where('idv',$id);
      $query = $this->db->delete('visage');  
      return $this->db->insert_id();
    }
  }
