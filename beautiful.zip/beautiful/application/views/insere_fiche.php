<!DOCTYPE html>
<html lang="en">
<head>
    <title>Consultations</title>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>-->
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.js"></script>' ?>

<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-icons.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-core.min.js"></script>' ?>

<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/uikit.min.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
</head>
<body>
<div class="bg-1">
  <!--==============================header=================================-->
   
  <?php $this->load->view('header'); ?>
    
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>  









      <!-- <div class="bg-5 bot-1">      
           <div class="container_24">
                <div class="grid_24">
                    <div class="line"></div>
                 </div>
                <div class="grid_16 top-3">
                    <h3>About spa consultations:</h3>
                    <div class="box-4">
                    	<div class=" border-bot wrap">
                            <div class="fleft">
                                <div class="number-3">
                                    <strong class="bg-clr-1">01.</strong>
                                    <div class="extra-wrap">
                                        <p><i class="clr-1"><strong>Lorem ipsum dolor sit amet, consectetur </strong></i><br>Vivamus hendrerit mauris ut dui gravida ut viverra lectus tincidunt. Cras mattis tempor eros nec tristique.</p>
                                    </div>
                                </div>
                                <div class="number-3 top-4">
                                    <strong class="bg-clr-2">02.</strong>
                                    <div class="extra-wrap">
                                        <p><i class="clr-2"><strong>Vivamus hendrerit mauris ut dui gravida ut</strong></i><br> viverra lectus tincidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula augue.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="fleft last">
                                <div class="number-3">
                                    <strong class="bg-clr-3">03.</strong>
                                    <div class="extra-wrap">
                                        <p><i class="clr-3"><strong>Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula augue. </strong></i><br>Maecenas faucibus sagittis cursus. Fusce tincidunt, tellus eget tristique cursus.</p>
                                    </div>
                                </div>
                                <div class="number-3 top-4">
                                    <strong class="bg-clr-4">04.</strong>
                                    <div class="extra-wrap">
                                        <p><i class="clr-4"><strong>Sed sed felis arcu, vel vehicula augue.</strong></i><br> Maecenas faucibus sagittis cursus. 
                        Fusce tincidunt, tellus eget tristique cursus, orci mi iaculis sem, sit amet dictum velit. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="link-1 fright">read more</a>
                    </div>
                    <div class="clear"></div>
                </div> 
                <div class="grid_8 top-3">
                	<div class="border-left">
                   		<h3>Useful links:</h3> 
                        <ul class="list-1 top-5">
                        	<li><a href="#">Lorem ipsum dolor sit amet</a></li>
                            <li><a href="#">Сonsectetur adipiscing elit</a></li>
                            <li><a href="#">Vivamus hendrerit mauris ut</a></li>
                            <li><a href="#">Gravida ut viverra lectus tincidunt</a></li>
                            <li><a href="#">Cras mattis tempor eros nec</a></li>
                            <li><a href="#">Sed sed felis arcu, vel vehicula</a></li>
                            <li><a href="#">Maecenas faucibus sagittis cursus</a></li>
                        </ul> 
                    </div>
                </div>    
                <div class="clear"></div>
           </div>
       </div> --> 
               <div class="bg-5 bot-1">  
                     <div class="uk-container uk-container-small"> 
                      <h3 class="uk-h3 uk-text-center" >
                        INFORMATION PERSONNELLE
                            </h3>             
                     <div class="uk-child-width-expand@s uk-text-center" uk-grid>

                        <div>
                                   
                            <?php $attributes = array('class' => 'uk-form-stacked uk-align-center'); ?>
                            <?php echo form_open($action, $attributes); ?>
                            
                                <div class="uk-margin-bottom ">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">nom et prénom :*</label>
                                  
                                      <?php echo form_error('nomp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('nomp', set_value('nomp'), array('class' => 'uk-input','placeholder'=>'votre nom et prénom...')) ?>
                                </div>
                                   
                                </div>
                                <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge" for="form-stacked-text">age :*</label>
                                     <?php echo form_error('age', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('age', set_value('age'), array('class' => 'uk-input','placeholder'=>'votre age...')) ?>
                                </div>
                                </div>
                                 <div class="uk-margin">
                                    <label class="uk-form-label uk-heading-xlarge  uk-text-left">sexe :*</label>
                                    <div class="uk-form-controls">
                                        <label><input class="uk-radio" type="radio" name="sexe" value="F" > femme </label>
                                        <label><input class="uk-radio" type="radio" name="sexe" value="M"> Homme </label>
                                    </div>
                                </div>
                                 <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Profession :*</label>
                                     <?php echo form_error('prof', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('prof', set_value('prof'), array('class' => 'uk-input','placeholder'=>'votre profession...')) ?>
                                </div>
                                </div>
                                
                                <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Numéro de téléphone :*</label>
                                         <?php echo form_error('tel', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('tel', set_value('tel'), array('class' => 'uk-input','placeholder'=>'votre nuémero sur 9 chiffres...')) ?>
                                    </div>
                                </div>
                                 <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Adresse :*</label>
                                     <?php echo form_error('adr', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('adr', set_value('adr'), array('class' => 'uk-input','placeholder'=>'votre adresse...')) ?>
                                    </div>
                                </div>
                                <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Mail :*</label>
                                     <?php echo form_error('mail', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('mail', set_value('mail'), array('class' => 'uk-input','placeholder'=>'votre mail...')) ?>
                                    </div>
                                </div>
                               <div class="uk-margin-bottom">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Etat civil :*</label>
                                     <?php echo form_error('etatc', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('etatc', set_value('etatc'), array('class' => 'uk-input','placeholder'=>'votre etatc...')) ?>
                                    </div>
                                </div>      
                        </div>
                        <div>
                           <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">Tabac :*</label>
                                     <?php echo form_error('tabac', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('tabac', set_value('tabac'), array('class' => 'uk-input','placeholder'=>'votre tabac...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">allergies :*</label>
                                     <?php echo form_error('aller', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('aller', set_value('aller'), array('class' => 'uk-input','placeholder'=>'votre aller...')) ?>
                                    </div>
                            </div>
                                
                             <div class="uk-margin-bottom">
                                    <label class="uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">gestation :*</label>
                                     <?php echo form_error('gest', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('gest', set_value('gest'), array('class' => 'uk-input','placeholder'=>'votre gestation...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">frequence Make-up :*</label>
                                     <?php echo form_error('frem', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('frem', set_value('frem'), array('class' => 'uk-input','placeholder'=>'votre frequence Make-up...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">Maladie de la peau connue :*</label>
                                     <?php echo form_error('mpc', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('mpc', set_value('mpc'), array('class' => 'uk-input','placeholder'=>'votre maladie de la peau connue...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge t" for="form-stacked-text">Traitement en cours :*</label>
                                     <?php echo form_error('tc', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('tc', set_value('tc'), array('class' => 'uk-input','placeholder'=>'votre traitement en cours...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge  " for="form-stacked-text">Cosmetique utilisé :*</label>
                                     <?php echo form_error('cu', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('cu', set_value('cu'), array('class' => 'uk-input','placeholder'=>'votre cosmetique utilisé...')) ?>
                                    </div>
                            </div>
                             <div class="uk-margin-bottom">
                                    <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">Soins maison :*</label>
                                     <?php echo form_error('sm', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('sm', set_value('sm'), array('class' => 'uk-input','placeholder'=>'votre soins maison...')) ?>
                                    </div>
                            </div>
                        </div>
                         
                    </div>
                    
                    <div class="uk-width-1-2@s uk-align-center">
                        <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">alcool :*</label>
                         <?php echo form_error('alcool', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                        <div class="uk-form-controls">
                            <?php echo form_input('alcool', set_value('alcool'), array('class' => 'uk-input','placeholder'=>'votre alcool...')) ?>
                        </div>
                    </div>
                    <div class="uk-width-1-2@s uk-align-center">
                        <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">imc :*</label>
                         <?php echo form_error('imc', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                        <div class="uk-form-controls">
                            <?php echo form_input('imc', set_value('imc'), array('class' => 'uk-input','placeholder'=>'votre imc...')) ?>
                        </div>
                    </div>
                    <div class="uk-width-1-2@s uk-align-center">
                            <label class=" uk-align-left uk-margin-small uk-form-label uk-heading-xlarge " for="form-stacked-text">hobbies :*</label>
                             <?php echo form_error('hobbies', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                            <div class="uk-form-controls">
                                <?php echo form_input('hobbies', set_value('hobbies'), array('class' => 'uk-input','placeholder'=>'votre hobbies...')) ?>
                            </div>
                    </div>
                  
                    <div class="uk-width-1-2@s uk-align-center">
                                <button class="uk-button mtn "><span uk-icon="icon:download"></span>envoyer<?php// echo $submit ?></button>         
                    </div>
                
                     </form>
                       </div>           
</div>










       <div class="bg-6 bot-1">
       		<div class="container_24">
                <div class="grid_24">
                    <div class="line"></div>
                    <div class="font-1 pad-2">Our therapies:</div>
                 </div>
                <div class="grid_7 box-2">
                    <h3>Therapy #1</h3>
                    <div class="img-border"><img src="images/page4-img1.jpg" alt=""></div>
                    <p class="border-1"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong>
                    Vivamus hendrerit mauris ut dui gravida ut lectus incidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula. </p>
                    <a href="#" class="link-1">read more</a>
                </div>   
                <div class="grid_7 box-2 prefix_1">
                    <h3 class="nowrap">Therapy #2</h3>
                    <div class="img-border"><img src="images/page4-img2.jpg" alt=""></div>
                    <p class="border-1"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong>
                    Vivamus hendrerit mauris ut dui gravida ut lectus incidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula. </p>
                    <a href="#" class="link-1">read more</a>
                </div>   
                <div class="grid_7 box-2 prefix_1">
                    <h3>Therapy #3</h3>
                    <div class="img-border"><img src="images/page4-img3.jpg" alt=""></div>
                    <p class="border-1"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong>
                    Vivamus hendrerit mauris ut dui gravida ut lectus incidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula.</p>
                    <a href="#" class="link-1">read more</a>
                </div>    
                <div class="clear"></div>
           </div>
       </div>
       <?php $this->load->view('footer'); ?>
</body>
</html>
