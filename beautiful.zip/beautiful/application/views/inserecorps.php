<!DOCTYPE html>
<html >
<head>

    <title>Consultations</title>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>-->
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.js"></script>' ?>

<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-icons.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-core.min.js"></script>' ?>

<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/uikit.min.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo link_tag('css/uikit-rtl.min.css'); ?>

<?php echo '<script src="'.base_url('js/uikit.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/uikit-icons.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
</head>
<body>
<div class="bg-1">
  <!--==============================header=================================-->
    
  <?php $this->load->view('header'); ?>
    
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>  

               <div class="bg-5 bot-1">  
                     <div class="uk-container uk-container-small "> 
                      <h3 class="uk-h3 uk-text-center" >
                        ETAT INITIAL AVANT LE 1ER SOIN
                            </h3>             
                    
                                   
                            <?php $attributes = array('class' => 'uk-form-stacked uk-align-center'); ?>
                            <?php echo form_open($action, $attributes); ?>
                            
                                <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">FERMETE/10 :*</label>
                                  
                                      <?php echo form_error('ferm', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('ferm', set_value('ferm'), array('class' => 'uk-input','placeholder'=>'fermete...')) ?>
                                </div>
                                   
                                </div>
                                <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge" for="form-stacked-text">VERGETURE/10 :*</label>
                                     <?php echo form_error('verg', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('verg', set_value('verg'), array('class' => 'uk-input','placeholder'=>'votre vergeture...')) ?>
                                </div>
                                </div>
                                
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">CELLULITE/10 :*</label>
                                     <?php echo form_error('cell', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('cell', set_value('cell'), array('class' => 'uk-input','placeholder'=>'votre cellulite...')) ?>
                                </div>
                                </div>
                                
                                <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">NECESSITE D'EPILATION/10 :*</label>
                                         <?php echo form_error('ne', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('ne', set_value('ne'), array('class' => 'uk-input','placeholder'=>'necessite d\'epilation...')) ?>
                                    </div>
                                </div>
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">ETAT DES MAINS :*</label>
                                     <?php echo form_error('etm', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('etm', set_value('etm'), array('class' => 'uk-input','placeholder'=>'votre etat des mains...')) ?>
                                    </div>
                                </div>
                                <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">ETAT DES PIEDS :*</label>
                                     <?php echo form_error('edp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('edp', set_value('edp'), array('class' => 'uk-input','placeholder'=>'votre etat des pieds...')) ?>
                                    </div>
                                </div>
                               <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">ETAT DE LA POITRINE :*</label>
                                     <?php echo form_error('desmains', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('edlp', set_value('edlp'), array('class' => 'uk-input','placeholder'=>'votre etat de la poitrine...')) ?>
                                    </div>
                                </div>  
                                <h6 class="uk-h3 uk-text-center"> DIAGNOTIC ET PRESCRIPTION
                                </h6>  
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">coprs:*</label>
                                     <?php echo form_error('descorps', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('descorps', set_value('descorps'), array('class' => 'uk-input','placeholder'=>'corps...')) ?>
                                    </div>
                                </div> 
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">MAINS :*</label>
                                     <?php echo form_error('desmains', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('desmains', set_value('desmains'), array('class' => 'uk-input','placeholder'=>'pieds...')) ?>
                                    </div>
                                </div> 
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">pieds :*</label>
                                     <?php echo form_error('despieds', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('despieds', set_value('despieds'), array('class' => 'uk-input','placeholder'=>'pieds...')) ?>
                                    </div>
                                </div>
                                 <div class="uk-width-1-2@s uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">POITRINE :*</label>
                                     <?php echo form_error('despoit', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('despoit', set_value('despoit'), array('class' => 'uk-input','placeholder'=>'Description de la poitrine...')) ?>
                                    </div>
                                </div>
                        </div>
                       
                    <div class="uk-width-1-2@s uk-align-center uk-align-center">
                                <button class="uk-button <?php echo $couleur ?> "><span uk-icon="icon:download"></span><?php echo $submit ?></button>         
                    </div>
                
                     </form>
                       </div>           
</div>

      
      <?php $this->load->view('footer'); ?>
</body>
</html>