<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contacts</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
   		<script type="text/javascript" src="js/html5.js"></script>
    	<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
	<![endif]-->
</head>
<body>
<div class="bg-1">
  <!--==============================header=================================-->
     <?php $this->load->view('header'); ?>
    
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>   
       <div class="bg-5 bot-1">      
           <div class="container_24">
                <div class="grid_24">
                    <div class="line"></div>
                 </div>
                <div class="grid_7 top-6">
                    <h3>Contact info:</h3>
                    <dl class="adr">
                        <dt class="clr-1"><strong><i>Spasalon</i></strong></dt>
                        <dd>8901 Marmora Road, Glasgow, D04 89GR</dd>
                        <dd><span>Telephone:</span><strong>+1 959 603 6035</strong></dd>
                        <dd><span>Fax:</span><strong>+1 504 889 9898</strong></dd>
                        <dd><span>Email:</span><a href="#" class="link">mail@spasalon.com</a></dd>
                        <dd>&nbsp;</dd>
                        <dd>9863 Mill Road, Cambridge, MG09 99HT</dd>
                        <dd><span>Telephone:</span><strong>+1 959 603 6035</strong></dd>
                        <dd><span>Fax:</span><strong>+1 504 889 9898</strong></dd>
                        <dd><span>Email:</span><a href="#" class="link">mail@spasalon.com</a></dd>
                    </dl> 
                </div> 
                <div class="grid_17">
                	<div class="border-left top-6">
                   		<h3>Contact form:</h3> 
                        <form id="form" method="post" >
                          <fieldset>
                            <label><strong>Full name:</strong><input type="text" value=""><strong class="clear"></strong></label>
                            <label><strong>Email:</strong><input type="text" value=""><strong class="clear"></strong></label>
                            <label><strong>Message:</strong><textarea></textarea><strong class="clear"></strong></label>
                            <strong class="clear"></strong>
                            <div class="btns"><a href="#" class="link-1">clear</a><a href="#" class="link-1" onClick="document.getElementById('form').submit()">send</a></div>
                          </fieldset>  
                        </form> 
                    </div>
                </div>    
                <div class="clear"></div>
           </div>
       </div>  
        <?php $this->load->view('footer'); ?>     
</body>
</html>