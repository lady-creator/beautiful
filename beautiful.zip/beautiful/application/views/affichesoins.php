<!DOCTYPE html>
<html >
<head>

    <title>Consultations</title>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>-->
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.js"></script>' ?>

<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-icons.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-core.min.js"></script>' ?>

<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/uikit.min.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
</head>
<body>
<div class="bg-1">
  

  <?php $this->load->view('header'); ?>

     <!-- Start Styles. Move the 'style' tags and everything between them to between the 'head' tags -->


  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>  

               <div class="bg-5 bot-1">  
                     <div class="uk-container uk-container-medium "> 
                            <h3 class="uk-h3 uk-text-center" >
                            FICHE DE SUIVIS DES SOINS DE VISAGE ET CORPS
                            
                            </h3>    
                            <?php //print_r($_SESSION) ?>
                             <a class=" uk-button" style="background:#626167; color:#fff; " href=" <?php echo base_url('visage/newvisage/'.$_SESSION['ida']) ?>"  uk-tooltip="soins visage">+SOIN DU VISAGE</a>
                            
                              <a class="uk-button uk-button-danger" href=" <?php echo base_url('corp/newcorps/'.$_SESSION['ida']) ?>"  uk-tooltip="soins corps">+SOIN DU CORPS</a>    
                      <div class=" uk-overflow-auto">   
                        <table class="uk-table " style="border:2px solid black;font-size: 14px;background-color:#f2f2f2;border-collapse:collapse;color:#000;">

                          <tbody >
                               <?php foreach ($personne as $pers):?>
                              <tr >
                                  <td ><?php echo $pers->idpers; ?>NOM ET PRENOM</td>
                                  <td><?php echo $pers->nomp; ?></td>
                                  <td >TELEPHONE </td>
                                  <td><?php echo $pers->tel; ?></td>
                                  <TD>TABAC</TD>
                                    <td><?php echo $pers->tabac2; ?></td>

                                    <td >MALADIE CONNU DE LA PEAU</td>
                                    <td><?php echo $pers->mpc; ?></td>
                              </tr>
                               <tr >
                                  <td>AGE</td>
                                  <td><?php echo $pers->age; ?></td>
                                  <td>ADRESSE</td>
                                   <td><?php echo $pers->adr; ?></td>
                                   <td>ALLERGIES</td>
                                    <td><?php echo $pers->aller; ?></td>
                                    <td>TRAITEMENT EN COURS</td>
                                    <td><?php echo $pers->tc; ?></td>
                                    <td>ALCOOL</td>
                                    <td><?php echo $pers->alcool; ?></td>
                              </tr>
                               <tr>
                                   <td>SEXE</td>
                                  <td><?php echo $pers->sexe; ?></td>
                                   <td>ADRESSE MAIL</td>
                                    <td><?php echo $pers->mail; ?></td>
                                    <td>GESTATION</td>
                                    <td><?php echo $pers->gest; ?></td>
                                    <td>COSMETIQUE UTILISEE</td>
                                    <td><?php echo $pers->cu; ?></td>
                                    <td>IMC</td>
                                    <td><?php echo $pers->imc; ?></td>
                              </tr>
                               <tr>
                                  <td>profession</td>
                                  <td><?php echo $pers->prof; ?></td>
                                   <td>ETAT CIVIL</td>
                                  <td><?php echo $pers->etatc; ?></td>
                                   <td>FREQUENCE MAKE-UP</td>
                                  <td><?php echo $pers->frem; ?></td>
                                   <td>SOINS MAISON</td>
                                  <td><?php echo $pers->sm; ?></td>
                                   <td>HOBBIES</td>
                                  <td><?php echo $pers->hobbies; ?></td>
                              </tr> 
                             <?php endforeach; ?>
                          </tbody>
                      </table>
                      </div>  
                    <div class="uk-child-width-expand@s uk-grid-small uk-text-center" uk-grid>
                      <div class="uk-width-3-5">
                          <div class="uk-card uk-card-default uk-card-body">
                            <h5 style="font-size:18px;">SOINS DE VISAGE</h5>
                            <table class="uk-table uk-text-left uk-table-divider" style="border:2px solid black;font-size:14px;">
                                <caption class="uk-text-center" style="color:#000;font-size:18px;">ETAT INITIAL AVANT LE 1ER SOIN </caption>
                                <thead style="color:#000;font-size:18px;">
                                    <tr>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                    </tr>
                                </thead>
                                <TBODY style="border:2px;">
                                  <?php if (count($corp)) :
                                    
                                  ?>
                                  <?php foreach ($visage as $v):?>
                                    <tr>
                                        <td>ETAT DE LA PEAU</td>
                                        
                                        <td><?php echo $v->ep; ?></td>
                                        <td>COMEDONS</td>
                                        <td><?php echo $v->comed; ?></td>
                                        
                                    </tr>
                            
                                    <tr>
                                        <td>BRILLANCE</td>
                                        <td><?php echo $v->bril; ?></td>
                                        <td>PAPULES/PUSTULES</td>
                                         <td><?php echo $v->pp; ?></td>
                                        
                                    </tr>
                                    <tr>
                                      <td>GRAIN DE PEAU</td>
                                         <td><?php echo $v->gp; ?></td>
                                        <td>ETAT DES PORES</td>
                                         <td><?php echo $v->etp; ?></td>
                                    </tr>
                                    <tr>
                                        <td>COULEUR DU TEINT</td>
                                        <td><?php echo $v->ct; ?></td>
                                        <td>CIRCULATION SANGUINE</td>
                                         <td><?php echo $v->cs; ?></td>
                                    </tr>
                                    <tr>
                                       <td>HYDRATATION/10</td>
                                        <td><?php echo $v->hydra; ?></td>
                                         <td>SOURCILS</td>
                                          <td><?php echo $v->sourci; ?></td>
                                    </tr>
                                    <tr>
                                       <td>RIDES/RIDULES</td>
                                        <td><?php echo $v->rr; ?></td>
                                         <td>DUVET</td>
                                          <td><?php echo $v->duvet; ?></td>
                                    </tr>
                                    <tr>
                                       <td>IMPERFECTION</td>
                                        <td><?php echo $v->imper; ?></td>
                                         <td>AUTRES</td>
                                          <td><?php echo $v->autres; ?></td>
                                    </tr>
                                    <tr>
                                       <td>TYPE DE PEAU</td>
                                        <td><?php echo $v->tp; ?></td>
                                         <td></td>
                                          <td></td>
                                    </tr>
                                    <tr>
                                       <td colspan="3" class="uk-text-center" style="color:#000;font-size:18px;">DIAGNOTIC ET PRESCRIPTION</td>
                                        <td></td>
                                         <td></td>
                                          <td></td>
                                    </tr>
                                     <tr>
                                       <td colspan="4"> <?php echo $v->descrit; ?></td>
                                        <td></td>
                                         <td></td>
                                          <td></td>
                                    </tr>
                                  <?php endforeach; ?>
                                   <?php else: ?>
                                        <tr><td><a class="uk-button uk-button-primary" href=" <?php echo base_url('visage/newvisage/'.$_SESSION['ida']) ?>" uk-icon="icon:play-circle" uk-tooltip="enregistré l'etat initial avant le 1er soin">+soins de visage état initial</a> </td></tr>
                                    <?php endif ?>
                                </tbody>
                            </table>
                            <hr style="border:2px solid black;">
                          
                              <?php if (count($visages)): ?>
                                
                             <?php $i=1; ?>
                              <?php foreach ($visages as $v):?>
                                  <h3 class="uk-text-center" style="color:red;font-size:18px;">EVOLUTION</h3>
                             <table class="uk-table uk-text-left uk-table-divider">
 
                                <thead>
                                    <tr>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                    </tr>
                                </thead>
                                <TBODY>
                                 
                                    <tr>
                                        <td>ETAT DE LA PEAU</td>
                                        
                                        <td><?php echo $v->ep; ?></td>
                                        <td>COMEDONS</td>
                                        <td><?php echo $v->comed; ?></td>
                                        
                                    </tr>
                            
                                    <tr>
                                        <td>BRILLANCE</td>
                                        <td><?php echo $v->bril; ?></td>
                                        <td>PAPULES/PUSTULES</td>
                                         <td><?php echo $v->pp; ?></td>
                                        
                                    </tr>
                                    <tr>
                                      <td>GRAIN DE PEAU</td>
                                         <td><?php echo $v->gp; ?></td>
                                        <td>ETAT DES PORES</td>
                                         <td><?php echo $v->etp; ?></td>
                                    </tr>
                                    <tr>
                                        <td>COULEUR DU TEINT</td>
                                        <td><?php echo $v->ct; ?></td>
                                        <td>CIRCULATION SANGUINE</td>
                                         <td><?php echo $v->cs; ?></td>
                                    </tr>
                                    <tr>
                                       <td>HYDRATATION/10</td>
                                        <td><?php echo $v->hydra; ?></td>
                                         <td>SOURCILS</td>
                                          <td><?php echo $v->sourci; ?></td>
                                    </tr>
                                    <tr>
                                       <td>RIDES/RIDULES</td>
                                        <td><?php echo $v->rr; ?></td>
                                         <td>DUVET</td>
                                          <td><?php echo $v->duvet; ?></td>
                                    </tr>
                                    <tr>
                                       <td>IMPERFECTION</td>
                                        <td><?php echo $v->imper; ?></td>
                                         <td>AUTRES</td>
                                          <td><?php echo $v->autres; ?></td>
                                    </tr>
                                    <tr>
                                       <td>TYPE DE PEAU</td>
                                        <td><?php echo $v->tp; ?></td>
                                         <td></td>
                                          <td></td>
                                    </tr>
                                    <tr>
                                       <td colspan="3" class="uk-text-center" style="color:#000;font-size:18px;">DIAGNOTIC ET PRESCRIPTION</td>
                                        <td></td>
                                         <td></td>
                                          <td></td>
                                    </tr>
                                     <tr>
                                       <td colspan="3">  <?php echo $v->descrit; ?></td>
                                        <td></td>
                                         <td></td>
                                          
                                    </tr>
                                    <caption class="uk-text-center" style="color:#000;font-size:18px;">SOIN N° <?php echo $i ?>          DATE ::<?php echo "     ".$v->datesave; ?></caption>
                                    <?php $i++; ?>
                                  
                                  <tr><td colspan="3"> <a class="uk-button uk-button-secondary" href=" <?php echo base_url('visage/updatevisage/'.$v->idv) ?>"  uk-tooltip="apporter une modification"> MODIFIER SOIN DU VISAGE</a> </td></tr>
                                  <tr><td colspan=""> 

                                          <a href="#modal-example" class="uk-button " style="background:#626167; color:#fff; " uk-toggle>SUPPRIMER</a>

                                    <!-- This is the modal -->
                                    <div id="modal-example" uk-modal>
                                        <div class="uk-modal-dialog uk-modal-body">
                                            <h4 class="">êtes vous sûr de vouloir supprimer</h4>
                                            
                                            <p class="uk-text-right">
                                                <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
                                                <a class="uk-button " style="background:#626167; color:#fff; "  href=" <?php echo base_url('visage/delvisage/'.$v->idv) ?>"  uk-tooltip="supprimer ">SUPPRIMER </a>
                                            </p>
                                        </div>
                                    </div>


                                         </td></tr>

                                </tbody>
                            </table>
                            <hr style="border:2px solid black;">
                             <?php endforeach; ?>
                            <?php else: ?>
                            <h3>aucun soin de visage n'est enregistré</h3>
                             <?php endif ?>
                          </div>
                        </div>
                        <div class="uk-width-2-5">
                          <div class="uk-card uk-card-default uk-card-body">
                            






                            <h5 style="color:red;">SOINS DE CORPS</h5>
                            <table class="uk-table uk-text-left uk-table-divider uk-text-capitalize">
                                <caption class="uk-text-center" style="color:#000;font-size:18px;">ETAT INITIAL AVANT LE 1ER SOIN </caption>
                                <thead>
                                    <tr>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                        
                                    </tr>
                                </thead>
                                <TBODY>
                                  <?php if (count($corp)): 
                                    ?>
                                  <?php foreach ($corp as $v):?>
                                    <tr>
                                        <td>FERMETE/10</td>
                                        
                                        <td><?php echo $v->ferm; ?></td>
                                        
                                        
                                    </tr>
                            
                                    <tr>
                                        <td>VERGETURE/10</td>
                                        <td><?php echo $v->verg; ?></td>
                                        
                                    </tr>
                                    <tr>
                                      <td>CELLULITE/10</td>
                                         <td><?php echo $v->cell; ?></td>
                                        
                                    </tr>
                                    <tr>
                                        <td>NECESSITE D'EPILATION/10</td>
                                        <td><?php echo $v->ne; ?></td>
                                      
                                    </tr>
                                    <tr>
                                       <td>ETAT DES MAINS/10</td>
                                        <td><?php echo $v->etm; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>ETAT DES PIEDS</td>
                                        <td><?php echo $v->etp; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>ETAT DE LA POITRINE</td>
                                        <td><?php echo $v->etlp; ?></td>
                                         
                                    </tr>
                                    
                                    <tr>
                                       <td colspan="2" class="uk-text-center" style="color:#000;font-size:18px;">DIAGNOTIC ET PRESCRIPTION</td>
                                        <td></td>
                                      
                                    </tr>
                                    
                                    
                                     <tr>
                                       <td >CORPS</td>
                                        <td><?php echo $v->descorp; ?></td>
                                        
                                    </tr>
                                    <tr>
                                       <td>MAINS</td>
                                        <td><?php echo $v->desmain; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>PIEDS</td>
                                        <td><?php echo $v->despied; ?></td>
                                    </tr>
                                    <tr>
                                       <td>POITRINE</td>
                                        <td><?php echo $v->despoit; ?></td>
                                         
                                    </tr>
                                  <?php endforeach; ?>
                                  <?php else: ?>
                                        <tr><td><a class="uk-button uk-button-primary" href=" <?php echo base_url('corp/newcorps/'.$_SESSION['ida']) ?>" uk-icon="icon:play-circle" uk-tooltip="enregistré l'etat initial avant le 1er soin">+soins du corps ETAT INITIAL</a> </td></tr>
                                    <?php endif ?>
                                </tbody>
                            </table>
                            <hr style="border:2px solid black;">
                            <?php if (count($corps)): ?>
                             <?php foreach ($corps as $v):?>
                              <h3 class="uk-text-center" style="color:red;font-size:18px;">EVOLUTION</h3>
                             <table class="uk-table uk-text-left uk-table-divider" >
                               
                                <thead>
                                    <tr>
                                        <th>ETATS</th>
                                        <th>NOTES</th>
                                        
                                    </tr>
                                </thead>
                                <TBODY>
                                  <?php $i=1; ?>
                                 
                                     <tr>
                                        <td>FERMETE/10</td>
                                        
                                        <td><?php echo $v->ferm; ?></td>
                                        
                                        
                                    </tr>
                            
                                    <tr>
                                        <td>VERGETURE/10</td>
                                        <td><?php echo $v->verg; ?></td>
                                        
                                    </tr>
                                    <tr>
                                      <td>CELLULITE/10</td>
                                         <td><?php echo $v->cell; ?></td>
                                        
                                    </tr>
                                    <tr>
                                        <td>NECESSITE D'EPILATION/10</td>
                                        <td><?php echo $v->ne; ?></td>
                                      
                                    </tr>
                                    <tr>
                                       <td>ETAT DES MAINS/10</td>
                                        <td><?php echo $v->etm; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>ETAT DES PIEDS</td>
                                        <td><?php echo $v->etp; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>ETAT DE LA POITRINE</td>
                                        <td><?php echo $v->etlp; ?></td>
                                         
                                    </tr>
                                    
                                    <tr>
                                       <td colspan="2" class="uk-text-center" style="color:#000;font-size:18px;">DIAGNOTIC ET PRESCRIPTION</td>
                                        <td></td>
                                      
                                    </tr>
                                    
                                    
                                     <tr>
                                       <td >CORPS</td>
                                        <td><?php echo $v->descorp; ?></td>
                                        
                                    </tr>
                                    <tr>
                                       <td>MAINS</td>
                                        <td><?php echo $v->desmain; ?></td>
                                         
                                    </tr>
                                    <tr>
                                       <td>PIEDS</td>
                                        <td><?php echo $v->despied; ?></td>
                                    </tr>
                                    <tr>
                                       <td>POITRINE</td>
                                        <td><?php echo $v->despoit; ?></td>
                                         
                                    </tr>
                                     <caption>SOIN N° <?php echo $i ?>          DATE ::<?php echo "     ".$v->datesave; ?></caption>
                                    <?php $i++; ?>
                                     <tr><td colspan="3"> <a class="uk-button uk-button-danger" href=" <?php echo base_url('corp/updatecorps/'.$v->idCorps) ?>"  uk-tooltip="apporter une modification"> MODIFIER SOIN DU CORPS</a> </td></tr>
                                      <tr><td colspan=""> 

                                          <a href="#modal-example" class="uk-button " style="background:#626167; color:#fff; " uk-toggle>SUPPRIMER</a>

                                    <!-- This is the modal -->
                                    <div id="modal-example" uk-modal>
                                        <div class="uk-modal-dialog uk-modal-body">
                                            <h4 class="">êtes vous sûr de vouloir supprimer</h4>
                                            
                                            <p class="uk-text-right">
                                                <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
                                                <a class="uk-button " style="background:#626167; color:#fff; "  href=" <?php echo base_url('corp/delcorps/'.$v->idCorps) ?>"  uk-tooltip="supprimer ">SUPPRIMER </a>
                                            </p>
                                        </div>
                                    </div>


                                         </td></tr>
                                </tbody>
                            </table>
                             <?php endforeach; ?>
                            <?php else: ?>
                            <h3>aucun soin de corps n'est enregistré</h3>
                             <?php endif ?>
                          </div>
                      </div>
                     
                  </div>
                    <?php //echo $links; ?>
                         <a style="background:#626167; color:#fff; " class="uk-button " href=" <?php echo base_url('welcome/consultation') ?>" uk-icon="icon:play-circle" uk-tooltip="bac">BACK</a>
                       </div>           
                </div>
<a href="#" class="uk-align-right" style="background:#626167;text-align: center; color:#fff;height: 12px  "   uk-totop uk-scroll></a>
      <?php $this->load->view('footer'); ?>

</body>
</html>