<!DOCTYPE html>
<html lang="en">
<head>
    <title>About</title>
    <meta charset="utf-8">
   
<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo link_tag('css/slider.css'); ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/tms-0.4.1.js').'"></script>' ?>
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
    
    <script>
		$(document).ready(function(){				   	
			$('.slider')._TMS({
				show:0,
				pauseOnHover:true,
				prevBu:'.prev',
				nextBu:'.next',
				playBu:false,
				duration:10000,
				preset:'zoomer',
				pagination:true,
				pagNums:false,
				slideshow:7000,
				numStatus:false,
				banners:false,
				waitBannerAnimation:false,
				progressBar:false
			})
		});
	</script>
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
   		<script type="text/javascript" src="js/html5.js"></script>
    	<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
	<![endif]-->
</head>
<body>

<div class="bg-1">
   <h1><a href="<?php echo base_url() ?>"><img src="images/logo.jpeg" alt=""></a></h1>
  <!--==============================header=================================-->
    <header>

    	<div class="main">
        	<h1><a href="#"> </h1>
            <nav class="nav">  
                <ul class="menu">
                    <li class="current">
                        <?php echo anchor(base_url(),'Accueil'); ?>
                        </li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Our Staff</a></li>
                    <li class="left-1"><?php echo anchor(base_url('welcome/consultation'),'consultation'); ?></li>
                    <li><a href="#">Prices</a></li>
                    <li><a href="contacts.html">Contacts</a></li>
                </ul>
                <div class="clear"></div>
             </nav>
            <div id="slide">		
                <div class="slider">
                    <ul class="items">
                        <li><img src="images/slider-1.jpg" alt="" /></li>
                        <li><img src="images/slider-2.jpg" alt="" /></li>
                        <li><img src="images/slider-3.jpg" alt="" /></li>
                    </ul>
              </div>	
                <a href="#" class="prev"></a><a href="#" class="next"></a>
          </div> 
        </div>
    </header>  
    
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-2">
           <div class="bg-3 bot-2">
               <div class="container_24">
                    <div class="grid_24">
                        <div class=""><a href="#"></a></div>
                    </div>    
                   
                    <div class="grid_10 box-1 prefix_1">
                        <h2>soin du visage</h2>
                        <div class="img-border"><img src="images/page1-img3.jpg" alt=""></div>
                        <p class="border-1"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </strong><br>Vivamus sed arcu dui, eu tincidunt sem. Vivamus hendrerit mauris ut dui gravida ut viverra lectus tincidunt.
 Cras mattis tempor eros nec<br> tristique. </p>
                        <a href="#" class="link-1">read more</a>
                    </div>   
                    <div class="grid_10 box-1 prefix_1">
                        <h2>Soin du corps</h2>
                        <div class="img-border"><img src="images/page1-img4.jpg" alt=""></div>
                        <p class="border-1"><strong>Vivamus sed arcu dui, eu tincidunt sem.</strong><br>
Vivamus hendrerit mauris ut dui gravida ut viverra lectus tincidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel augue .Maecenas faucibus sagittis cursus. </p>
                        <a href="#" class="link-1">read more</a>
                    </div>   
                    <div class="clear"></div>
               </div>
           </div>
       </div>
       <div class="bg-4 bot-1">
        <div class="container_24">
             <div class="grid_24">
                <div class="line"></div>
                <div class="font-1 pad-1">The largest, most complete selection <span></span>
<strong><span>procedures at reasonable prices</span></strong></div>
             </div>
             <div class="grid_7">
             	<p class="border-bot"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sed arcu dui, eu </strong><br>
Vivamus hendrerit mauris ut dui gravida ut lectus tincidunt. Cras mattis tempor eros nec tristique. Sed sed felis arcu, vel vehicula augue. Maecenas faucibus sagittis cursus. </p>
                <a href="#" class="link-1 fright">read more</a>
             </div>
             <div class="grid_8 prefix_1">
             	<div class="border-left">
                	<div class="number">
                    	<strong class="bg-clr-1">01.</strong>
                    	<p class="extra-wrap"><i class="clr-1"><strong>Lorem ipsum dolor sit amet,</strong></i><br> consectetur adipiscing elit. Vivamus arcu dui, eu tincidunt sem. Vivamus </p>
                    </div>
                    <div class="number">
                    	<strong class="bg-clr-2">02.</strong>
                    	<p class="extra-wrap"><i class="clr-2"><strong>Vivamus sed arcu dui, eu tincidunt sem.</strong></i> Vivamus hendrerit mauris ut dui gravida ut viverra tincidunt.</p>
                    </div>
                </div>
             </div>
             
             <div class="clear"></div>
        </div>    
       </div>
       <?php $this->load->view('footer'); ?>
</body>
</html>