<!DOCTYPE html>
<html >
<head>

    <title>Consultations</title>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>-->
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.js"></script>' ?>

<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-icons.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-core.min.js"></script>' ?>

<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/uikit.min.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
</head>
<body>
<div class="bg-1">
  <!--==============================header=================================-->
    
  <?php $this->load->view('header'); ?>
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>  

               <div class="bg-5 bot-1">  
                     <div class="uk-container uk-container-small "> 
                            <h3 class="uk-h3 uk-text-center" >
                            LISTES DES CLIENTS ET FICHE DE SUIVI
                            </h3>             
                           <table class="uk-table uk-table-divider">
                        <thead>
                            <tr>
                                 <th>n°</th>
                                <th>nom et prenom</th>
                                
                                <th>profession</th>
                                <th>Adresse mail</th>
                                 <th>sexe</th>
                                 <th>ville</th>
                                 <th>age</th>
                                 <th>téléphone</th>
                                 <th>fiche de suivi</th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($personne as $pers):?>
                            <tr class="<?php //if( $pers->statut=='persin'): echo 'btn';else:echo 'mtn'; endif;?>">
                                <td><?php echo $pers->idpers; ?></td>
                                <td><?php echo $pers->nomp; ?></td>
                                <td><?php echo $pers->prof; ?></td>
                                <td><?php echo $pers->mail; ?></td>
                                <td><?php echo $pers->sexe; ?></td>
                                
                               <td><?php echo $pers->adr; ?></td>
                             <td><?php echo $pers->age; ?></td>
                              <td><?php echo $pers->tel; ?></td>
                                <td>
                                    <?php //if($_SESSION['statut']=='persin'): ?>
                                    <a class="uk-button uk-button-danger" href=" <?php echo base_url('Welcome/fichesoins/'.$pers->idpers) ?>" uk-icon="icon:play-circle" uk-tooltip="consulter la fiche">FICHE</a>
                                    <a href="" uk-icon="icon: heart"></a>
                                     <a href="<?php //echo base_url('insere/activepersin/'.$pers->ida)  //echo base_url('insere/activepersin/'.$pers->ida.'/'.$pers->statut) ?>">  
                                                <?php  
                                                    //if($pers->statut=='persin')
                                                       // echo '<span uk-icon="icon:check" uk-tooltip="changer le statut"></span>';
                                                    //else 
                                                      //  echo '<span  uk-icon="icon:close" uk-tooltip="changer le statut"></span>';
                                                ?>
                                        </a>
                                <?php //endif ?>
                                </td>
                            </tr>
                           <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php echo $links; ?>
                         <a class="" style="background:#626167; color:#fff; font-size:16px; line-height:24px; padding:4px 12px 10px 12px; display:inline-block; opacity: 0.6"  href=" <?php echo base_url('Welcome/inserefiche') ?>" uk-icon="icon:play-circle" uk-tooltip="Nnouveau client">AJOUTER UN NOUVEAU CLIENT</a>
                       </div>           
                </div>
<?php $this->load->view('footer'); ?>
</body>
</html>