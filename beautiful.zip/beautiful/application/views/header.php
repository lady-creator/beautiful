<!--==============================header=================================-->
    <header>
        <div class="main">
            <h1 class="logo-sub-pages"><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
            <nav class="nav-sub-pages">  
                <ul class="menu">
                    <li><li class="current">
                        <?php echo anchor(base_url(),'Accueil'); ?>
                    </li></li>
                    <li><a href="#">service</a></li>
                    <li class="left-1 current"><?php echo anchor(base_url('welcome/consultation'),'consultation'); ?></li>
                    <li><a href="#">price</a></li>
                    <li><?php echo anchor('welcome/contact','contact'); ?></li>
                </ul>
                <div class="clear"></div>
             </nav>
        </div>
    </header>  
    