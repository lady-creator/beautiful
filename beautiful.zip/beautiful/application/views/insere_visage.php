<!DOCTYPE html>
<html >
<head>

    <title>Consultations</title>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/grid_24.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>-->
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.js"></script>' ?>

<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-icons.min.js"></script>' ?>
<?php echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.4.6/js/uikit-core.min.js"></script>' ?>

<?php echo link_tag('css/reset.css'); ?>
<?php echo link_tag('css/uikit.min.css'); ?>
<?php echo link_tag('css/grid_24.css'); ?>
<?php echo link_tag('css/style.css'); ?>
<?php echo '<script src="'.base_url('js/jquery-1.7.min.js').'"></script>' ?>
<?php echo '<script src="'.base_url('js/jquery.easing.1.3.js').'"></script>' ?>
</head>
<body>
<div class="bg-1">
  <!--==============================header=================================-->
   
  <?php $this->load->view('header'); ?>
     
  <!--==============================content================================-->
    <section id="content">
       <div class="bg-3 bot-3">
           <div class="container_24">
                <div class="grid_24">
                    <div class="banner-bg"><a href="#"></a></div>
                </div>  
                <div class="clear"></div> 
           </div>
       </div>  

               <div class="bg-5 bot-1">  
                     <div class="uk-container uk-container-small "> 
                      <h3 class="uk-h3 uk-text-center" >
                        SOINS DU VISAGE
                            </h3>             
                             <div class="uk-child-width-expand@s uk-text-center" uk-grid>
                                <div>
                                     <?php $attributes = array('class' => 'uk-form-stacked uk-align-center'); ?>
                            <?php echo form_open($action, $attributes); ?>
                            
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">Etat DE LA PEAU :*</label>
                                  
                                      <?php echo form_error('ep', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('ep', set_value('ep'), array('class' => 'uk-input','placeholder'=>'etat de la peau...')) ?>
                                </div>
                                   
                                </div>
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge" for="form-stacked-text">BRILLANCE :*</label>
                                     <?php echo form_error('bril', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('bril', set_value('bril'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                </div>
                                </div>
                                
                                 <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">GRAIN DE PEAU :*</label>
                                     <?php echo form_error('gp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('gp', set_value('gp'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                </div>
                                </div>
                                
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">couleur de teint :*</label>
                                         <?php echo form_error('ct', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('ct', set_value('ct'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div>
                                 <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">HYDRATATION/10 :*</label>
                                     <?php echo form_error('hydra', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('hydra', set_value('hydra'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div>
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">RIDES/RIDULES :*</label>
                                     <?php echo form_error('rr', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('rr', set_value('rr'), array('class' => 'uk-input','placeholder'=>'votre etat des pieds...')) ?>
                                    </div>
                                </div>
                               <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">IMPERFECTIONS :*</label>
                                     <?php echo form_error('imper', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('imper', set_value('imper'), array('class' => 'uk-input','placeholder'=>'votre etat de la poitrine...')) ?>
                                    </div>
                                </div>  
                                
                                 <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text"> DIAGNOTIC ET PRESCRIPTION:*</label>
                                     <?php echo form_error('descrit', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_textarea('descrit', set_value('description'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div> 
                                
                                </div>
                                <div>
                                     <?php $attributes = array('class' => 'uk-form-stacked uk-align-center'); ?>
                            <?php echo form_open('', $attributes); ?>
                            
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">COMEDONS :*</label>
                                  
                                      <?php echo form_error('comed', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('comed', set_value('comed'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                </div>
                                   
                                </div>
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge" for="form-stacked-text">PAPULES/PUSTULES :*</label>
                                     <?php echo form_error('pp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('pp', set_value('pp'), array('class' => 'uk-input','placeholder'=>'votre vergeture...')) ?>
                                </div>
                                </div>
                                
                                 <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">ETAT DES PORES :*</label>
                                     <?php echo form_error('etp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                <div class="uk-form-controls">
                                    <?php echo form_input('etp', set_value('etp'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                </div>
                                </div>
                                
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">CIRCULATION SANGUINE/10 :*</label>
                                         <?php echo form_error('cs', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('cs', set_value('cs'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div>
                                 <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">SOURCILS :*</label>
                                     <?php echo form_error('sourci', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('sourci', set_value('sourci'), array('class' => 'uk-input','placeholder'=>'votre etat des mains...')) ?>
                                    </div>
                                </div>
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">DUVET :*</label>
                                     <?php echo form_error('duvet', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('duvet', set_value('duvet'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div>
                                <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">TYPE DE PEAU :*</label>
                                     <?php echo form_error('tp', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('tp', set_value('tp'), array('class' => 'uk-input','placeholder'=>'votre etat de la poitrine...')) ?>
                                    </div>
                                </div>  
                                
                               <div class=" uk-margin-bottom uk-align-center">
                                    <label class=" uk-text-left uk-form-label uk-heading-xlarge " for="form-stacked-text">AUTRES :*</label>
                                     <?php echo form_error('autre', '<div class="uk-label uk-label-danger">', '</div>'); ?>
                                    <div class="uk-form-controls">
                                        <?php echo form_input('autres', set_value('autres'), array('class' => 'uk-input','placeholder'=>'...')) ?>
                                    </div>
                                </div>  
                               
                                 
                                </div>
                             </div>
                                   
                           <div class=" uk-align-center uk-align-center">
                                <button class="uk-button <?php echo $couleur ?>"><span uk-icon="icon:download"></span><?php echo $submit ?></button>         
                    </div>
                        </div>
                       
                    
                
                     </form>
                       </div>           
</div>

     <?php $this->load->view('footer'); ?> 
</body>
</html>