<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('about');
	}
	public function consultxdation()
		{
			

			$data['titre']='fiche';
}
	public function consultation($f=NULL){

		//if(!empty($_SESSION['ida'])){
				$data['titre'] = 'camion';
				$this->load->library('pagination');
				$lpersonne=$this->M_personne->getpersonne();
				$sess=array(
				
				'nom'=>$lpersonne[0]->nomp,
				'statut'=>$lpersonne[0]->statut,
				'ida'=>$lpersonne[0]->idpers
				);
$this->session->set_userdata($sess);

			 $config['base_url']=site_url('Welcome/listepersonne');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_personne->getpersonne());
					$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$data['personne']=$this->M_personne->getpersonne();
				$this->pagination->initialize($config);
				$login=$this->input->get('login');	
				/*if(empty($login)){
							$data['personne']=$this->M_admin->geta($config['per_page'],$f);
				}else{
					$data['admin']=$this->M_admin->getadmin(array('login'=>$login));
				}

					$data['links']=$this->pagination->create_links();
		   		 $this->load->view('listeadmin', $data);
		    }else{
		    	redirect('');
		    }*/
//	}
		    $data['links']=$this->pagination->create_links();
		    $r=$data['personne']=$this->M_personne->geta($config['per_page'],$f);
		    
			$this->load->view('affpersonne', $data);
		}




////////////////////////fiche de suivi
		public function fichesoins($s){
			$lpersonne=$data['personne']=$this->M_personne->getpersonne(array('idpers'=>$s));
			$sess=array(
				
				'nom'=>$lpersonne[0]->nomp,
				'statut'=>$lpersonne[0]->statut,
				'ida'=>$lpersonne[0]->idpers
				);
			$this->session->set_userdata($sess);
			$data['visage']=$this->M_visage->getvisage(array('Pidpers'=>$s,'statut'=>'initial'));
			$data['visages']=$this->M_visage->getvisage(array('Pidpers'=>$s,'statut'=>'evolution'));
			$data['corp']=$this->M_corps->getcorps(array('Pidpers'=>$s,'statut'=>'initial'));
			$data['corps']=$this->M_corps->getcorps(array('Pidpers'=>$s,'statut'=>'evolution'));
			
						$this->load->view('affichesoins', $data);
		}



public function contact(){
			$lpersonne=$data['personne']=$this->M_personne->getpersonne(array('idpers'=>$s));
			$sess=array(
				
				'nom'=>$lpersonne[0]->nomp,
				'statut'=>$lpersonne[0]->statut,
				'ida'=>$lpersonne[0]->idpers
				);
			$this->session->set_userdata($sess);
			$data['visage']=$this->M_visage->getvisage(array('Pidpers'=>$s,'statut'=>'initial'));
			$data['visages']=$this->M_visage->getvisage(array('Pidpers'=>$s,'statut'=>'evolution'));
			$data['corp']=$this->M_corps->getcorps(array('Pidpers'=>$s,'statut'=>'initial'));
			$data['corps']=$this->M_corps->getcorps(array('Pidpers'=>$s,'statut'=>'evolution'));
			
		$this->load->view('footer', $data);
		}









		/////////////////////insere un nouveau client
		public function inserefiche(){
		$data['titre'] = 'fiche';
		$data['action']='welcome/inserefiche';
		$data['submit'] = 'Enregistrer';
		$data['tit']='creer un nouveau administrateur';
		
		//$data['admins'] = $this->M_admin->getadmin();
		$this->form_validation->set_rules('nomp', 'lang:nomc et prenom', 'strip_tags|trim|required|alpha');
		$this->form_validation->set_rules('mail', 'lang:mail', 'strip_tags|trim|required|is_unique[personne.mail]|valid_url');
		
		$this->form_validation->set_rules('sexe', 'lang:sexe', 'trim|required');
		$this->form_validation->set_rules('age', 'lang:age', 'trim|required|numeric');
		$this->form_validation->set_rules('prof', 'lang:profession', 'trim|required');
		$this->form_validation->set_rules('tel', 'lang:telephone', 'trim|required|min_length[9]|max_length[12]|numeric');
		$this->form_validation->set_rules('imc', 'lang:imc', 'trim|required');
		$this->form_validation->set_rules('sm', 'lang:soins maison', 'trim|required');

			if($this->form_validation->run())
					{
					
			$pers = array(
				'nomp' => $this->input->post('nomp'),
				'mail' => $this->input->post('mail'),
				'statut' => 'actif',
				'tel' => $this->input->post('tel'),
				'prof' => $this->input->post('prof'),
				'adr' => $this->input->post('adr'),
				'age' =>$this->input->post('age'),
				'sexe' => $this->input->post('sexe'),
				'etatc' => $this->input->post('etatc'),
				'tabac2' => $this->input->post('tabac'),
				'aller' => $this->input->post('aller'),
				'gest' => $this->input->post('gest'),
				'frem' => $this->input->post('frem'),
				'mpc' => $this->input->post('mpc'),
				'tc' => $this->input->post('tc'),
				'cu' => $this->input->post('cu'),
				'sm' => $this->input->post('sm'),
				'alcool' => $this->input->post('alcool'),
				'hobbies' => $this->input->post('hobbies'),
				'imc' => $this->input->post('imc'),
				'datesave' => date('Y-m-d'),
				'dateupdate' =>date('Y-m-d')
			);
			
			if($this->M_personne->addpersonne($pers))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('Welcome/consultation');
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('welcome/inserefiche');
				}
			
		}
		
		$this->load->view('insere_fiche', $data,false);

	}

}
