<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Corp extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('about');
	}
	
	public function affichecorps($f=NULL){

		//if(!empty($_SESSION['ida'])){
				$data['titre'] = 'camion';
				$this->load->library('pagination');
				$lcorps=$this->M_corps->getcorps();
				$sess=array(
				
				'nom'=>$lcorps[0]->nomp,
				'statut'=>$lcorps[0]->statut,
				'ida'=>$lcorps[0]->idpers
				);
				$this->session->set_userdata($sess);
				$config['base_url']=site_url('Corp/affichecorps');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_corps->getcorps());
					$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$data['corps']=$this->M_corps->getcorps();
				$this->pagination->initialize($config);
				$login=$this->input->get('login');	
				/*if(empty($login)){
							$data['corps']=$this->M_admin->geta($config['per_page'],$f);
				}else{
					$data['admin']=$this->M_admin->getadmin(array('login'=>$login));
				}

					$data['links']=$this->pagination->create_links();
		   		 $this->load->view('listeadmin', $data);
		    }else{
		    	redirect('');
		    }*/
//	}
		    $data['links']=$this->pagination->create_links();
		    $r=$data['corps']=$this->M_corps->geta($config['per_page'],$f);
		    
			$this->load->view('affcorps', $data);
		}


		/////////////////////insere un nouveau client
		public function newcorps($new){
		$data['titre'] = 'fiche';
		$data['action']='corp/newcorps/'.$new;
		$data['submit'] = 'ENVOYER';
		$data['couleur'] = 'uk-button-danger';
		$data['tit']='creer un nouveau administrateur';
		
		//$data['admins'] = $this->M_admin->getadmin();
		$this->form_validation->set_rules('ferm', 'lang:fermete', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('verg', 'lang:vergeture', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('cell', 'lang:cellulite', 'trim|required|integer');
		$this->form_validation->set_rules('etm', 'lang:etat des mains', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('edp', 'lang:etat des pieds', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('edlp', 'lang:etat de la poitrine', 'strip_tags|trim|required|integer');
			if (count($this->M_corps->getcorps(array('Pidpers'=>$new)))) {
				$statut='evolution';
			}else{
				$statut='initial';
			}
			if($this->form_validation->run())
					{
					
			$corps = array(
				'Pidpers'=>$new,
				'ferm' => $this->input->post('ferm'),
				'verg' => $this->input->post('verg'),
				'statut' => $statut,
				'cell' => $this->input->post('cell'),
				'ne' => $this->input->post('ne'),
				'etm' => $this->input->post('etm'),
				'etp' =>$this->input->post('edp'),
				'etlp' => $this->input->post('edlp'),
				'descorp' => $this->input->post('descorps'),
				'desmain' => $this->input->post('desmains'),
				'despied' => $this->input->post('despieds'),
				'despoit' => $this->input->post('despoit'),
				'datesave' => date('Y-m-d'),
				'dateupdate' =>date('Y-m-d')
			);
			
			if($this->M_corps->addcorps($corps))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('Welcome/fichesoins/'.$new);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('corp/newcoprs');
				}
			
		}
		
		$this->load->view('inserecorps', $data);

	}


	public function updatecorps($m2){
		$data['titre'] = 'coprs';
		$data['submit'] = 'Modifier';
		$data['couleur'] = 'uk-button-danger';
		$data['action']='corp/updatecorps/'.$m2;
		$l=$this->M_corps->getcorps(array('idCorps'=>$m2));
		$this->form_validation->set_rules('ferm', 'lang:fermete', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('verg', 'lang:vergeture', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('cell', 'lang:cellulite', 'trim|required|integer');
		$this->form_validation->set_rules('etm', 'lang:etat des mains', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('edp', 'lang:etat des pieds', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('edlp', 'lang:etat de la poitrine', 'strip_tags|trim|required|integer');
		if($this->form_validation->run())
		{
			$corps = array(
				'Pidpers'=>$m2,
				'ferm' => $this->input->post('ferm'),
				'verg' => $this->input->post('verg'),
				
				'cell' => $this->input->post('cell'),
				'ne' => $this->input->post('ne'),
				'etm' => $this->input->post('etm'),
				'etp' =>$this->input->post('edp'),
				'etlp' => $this->input->post('edlp'),
				'descorp' => $this->input->post('descorps'),
				'desmain' => $this->input->post('desmains'),
				'despied' => $this->input->post('despieds'),
				'despoit' => $this->input->post('despoit'),
				
				'dateupdate' =>date('Y-m-d')
			);
			print_r($corps);
			if($this->M_corps->updatecorps($corps))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('Welcome/fichesoins/'.$l[0]->Pidpers);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('Welcome/fichesoins/'.$l[0]->Pidpers);
				}
			
		}
		$this->load->view('inserecorps', $data);
	}
	public function delcorps($idp){
		
		//$phot =$this->M_admim->getPhoto(array('ida'=>$idp));
		$l=$this->M_corps->getcorps(array('idCorps'=>$idp));
		if($this->M_corps->delcorps($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('Welcome/fichesoins/'.$l[0]->Pidpers);
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('Welcome/fichesoins/'.$l[0]->Pidpers););
			}
		//$this->load->view('chauf/produit/');
		
	}


}
